"""
Ejercicio 1 - Tokenizador simple (analizador léxico)
Autor: Jorge Mario Prado Medina

Un analizador léxico (lexer) lee una cadena de caracteres y la divide en
"tokens": las unidades mínimas con significado (números, identificadores,
operadores...). Aquí se construye con expresiones regulares del módulo `re`,
sin librerías externas.
"""

import re

# Especificación de tokens: (TIPO, patrón regex).
# El ORDEN importa: se prueban de arriba hacia abajo.
ESPECIFICACION_TOKENS = [
    ("NUM",    r"\d+(\.\d+)?"),        # Enteros o decimales: 3, 5, 2.75
    ("ID",     r"[A-Za-z_]\w*"),       # Identificadores: x, total, _var1
    ("ASSIGN", r"="),                  # Operador de asignación
    ("OP",     r"[+\-*/]"),            # Operadores aritméticos
    ("LPAREN", r"\("),                 # Paréntesis de apertura
    ("RPAREN", r"\)"),                 # Paréntesis de cierre
    ("SKIP",   r"[ \t]+"),             # Espacios y tabs (se ignoran)
    ("ERROR",  r"."),                  # Cualquier otro carácter = error
]

# Se unen todos los patrones en UNA sola regex con grupos con nombre:
# (?P<NUM>...)|(?P<ID>...)|...  -> así match.lastgroup nos dice el tipo.
REGEX_TOKENS = re.compile(
    "|".join(f"(?P<{tipo}>{patron})" for tipo, patron in ESPECIFICACION_TOKENS)
)


def tokenizar(codigo):
    """Recibe una cadena y devuelve una lista de tuplas (TIPO, VALOR, POSICION)."""
    tokens = []
    # re.finditer recorre la cadena encontrando coincidencias consecutivas
    for coincidencia in REGEX_TOKENS.finditer(codigo):
        tipo = coincidencia.lastgroup          # Nombre del grupo que coincidió
        valor = coincidencia.group()           # Texto encontrado
        posicion = coincidencia.start()        # Posición en la cadena

        if tipo == "SKIP":
            continue                           # Los espacios no son tokens
        if tipo == "ERROR":
            raise SyntaxError(
                f"Carácter inesperado '{valor}' en la posición {posicion}"
            )
        if tipo == "NUM":
            # Convertimos el texto a número real (int o float)
            valor = float(valor) if "." in valor else int(valor)

        tokens.append((tipo, valor, posicion))
    return tokens


if __name__ == "__main__":
    ejemplos = [
        "x = 3 + 5 * 2",
        "total = (precio + 2.5) / cantidad",
        "y = x - 10",
    ]
    for ejemplo in ejemplos:
        print(f"\nEntrada: {ejemplo!r}")
        for tipo, valor, pos in tokenizar(ejemplo):
            print(f"  {tipo:<7} {str(valor):<10} (pos {pos})")

    # Ejemplo de error léxico
    print("\nEntrada con error: 'x = 3 $ 2'")
    try:
        tokenizar("x = 3 $ 2")
    except SyntaxError as e:
        print("  Error léxico:", e)
