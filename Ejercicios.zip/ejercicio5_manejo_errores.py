"""
Ejercicio 5 - Manejo de errores sintácticos con mensajes claros
Autor: Jorge Mario Prado Medina

Es el parser del ejercicio 2, modificado para:
  1. Guardar la POSICIÓN de cada token, y así decir dónde está el error.
  2. No "reventar" con una excepción de Python: se captura el error y se
     muestra un mensaje entendible para el usuario.
  3. Recuperación en MODO PÁNICO: si hay varias expresiones separadas por ';'
     y una tiene error, el parser descarta tokens hasta el siguiente ';'
     (token de sincronización) y sigue analizando las demás. Así reporta
     TODOS los errores en una sola pasada, no solo el primero.
"""

import re


class ErrorSintactico(Exception):
    """Excepción propia con la posición y un mensaje claro."""
    def __init__(self, posicion, mensaje, tipo="Error de sintaxis"):
        self.posicion = posicion
        self.mensaje = mensaje
        super().__init__(f"{tipo} en la posición {posicion}: {mensaje}")


# Token = (tipo, valor, posicion)
REGEX = re.compile(r"(?P<NUM>\d+(\.\d+)?)|(?P<OP>[+\-*/()])|(?P<SEP>;)|(?P<SKIP>\s+)|(?P<ERROR>.)")


def tokenizar(texto):
    tokens = []
    for m in REGEX.finditer(texto):
        tipo = m.lastgroup
        if tipo == "SKIP":
            continue
        valor = float(m.group()) if tipo == "NUM" else m.group()
        tokens.append((tipo, valor, m.start()))
    tokens.append(("FIN", "fin de la expresión", len(texto)))
    return tokens


def describir(token):
    """Texto amigable para mostrar el token encontrado."""
    tipo, valor, _ = token
    if tipo == "FIN":
        return "el fin de la expresión"
    if tipo == "NUM":
        return f"'{valor:g}'"
    return f"'{valor}'"


class Parser:
    SINCRONIZACION = ("SEP", "FIN")   # tokens donde el modo pánico se detiene

    def __init__(self, texto):
        self.texto = texto
        self.tokens = tokenizar(texto)
        self.pos = 0
        self.errores = []

    def actual(self):
        return self.tokens[self.pos]

    def error(self, mensaje):
        """Lanza un ErrorSintactico con la posición del token actual."""
        raise ErrorSintactico(self.actual()[2], mensaje)

    def consumir(self):
        token = self.actual()
        self.pos += 1
        return token

    # ------------------ modo pánico ------------------
    def sincronizar(self):
        """Descarta tokens hasta encontrar un token de sincronización."""
        while self.actual()[0] not in self.SINCRONIZACION:
            self.pos += 1

    # ------------------ entrada principal ------------------
    def parsear_todo(self):
        """Analiza expresiones separadas por ';'. Devuelve lista de resultados."""
        resultados = []
        while True:
            try:
                valor = self.expresion()
                if self.actual()[0] == "ERROR":
                    self.error(f"carácter no válido '{self.actual()[1]}'")
                if self.actual()[0] not in self.SINCRONIZACION:
                    self.error(f"se esperaba un operador o el fin, se encontró {describir(self.actual())}")
                resultados.append(valor)
            except ErrorSintactico as e:
                self.errores.append(e)
                resultados.append(None)
                self.sincronizar()                     # <- MODO PÁNICO
            except ZeroDivisionError:
                self.errores.append(ErrorSintactico(self.actual()[2], "división entre cero",
                                                    tipo="Error de ejecución"))
                resultados.append(None)
                self.sincronizar()

            if self.actual()[0] == "SEP":
                self.consumir()                        # saltar ';' y seguir
            else:
                break
        return resultados

    # ------------------ gramática (igual que ejercicio 2) ------------------
    def expresion(self):
        valor = self.termino()
        while self.actual()[1] in ("+", "-"):
            op = self.consumir()[1]
            derecho = self.termino()
            valor = valor + derecho if op == "+" else valor - derecho
        return valor

    def termino(self):
        valor = self.factor()
        while self.actual()[1] in ("*", "/"):
            op = self.consumir()[1]
            derecho = self.factor()
            valor = valor * derecho if op == "*" else valor / derecho
        return valor

    def factor(self):
        tipo, valor, _ = self.actual()
        if tipo == "NUM":
            self.consumir()
            return valor
        if valor == "(":
            self.consumir()
            resultado = self.expresion()
            if self.actual()[1] != ")":
                self.error(f"se esperaba ')', se encontró {describir(self.actual())}")
            self.consumir()
            return resultado
        if valor == "-":
            self.consumir()
            return -self.factor()
        if tipo == "ERROR":
            self.error(f"carácter no válido '{valor}'")
        self.error(f"se esperaba un número, se encontró {describir(self.actual())}")


def mostrar_error(texto, error):
    """Imprime el mensaje y una flecha ^ señalando la posición del error."""
    print(f"  {error}")
    print(f"    {texto}")
    print(f"    {' ' * error.posicion}^")


def analizar(texto):
    print(f"\nEntrada: {texto!r}")
    parser = Parser(texto)
    resultados = parser.parsear_todo()
    for r in resultados:
        if r is not None:
            print(f"  Resultado: {int(r) if r == int(r) else r}")
    for e in parser.errores:
        mostrar_error(texto, e)


if __name__ == "__main__":
    analizar("2 + 3 * (4 - 1)")          # correcto -> 11
    analizar("2 + * 3")                   # el ejemplo del enunciado
    analizar("(2 + 3")                    # falta ')'
    analizar("4 5")                       # falta operador
    analizar("2 + 3 $ 1")                 # carácter inválido
    analizar("8 / 0")                     # división entre cero
    # Modo pánico: la 2da expresión falla, pero la 1ra y la 3ra se evalúan
    analizar("1 + 1; 2 + * 3; 10 * 2; (5 -")
