"""
Ejercicio 4 - Construcción de un AST para un mini-lenguaje de asignaciones
Autor: Jorge Mario Prado Medina

Un AST (Árbol de Sintaxis Abstracta) representa la ESTRUCTURA de un programa
sin los detalles innecesarios (espacios, paréntesis, punto y coma...).
Por ejemplo,  y = x + 5  se vuelve:

    Asignacion(y)
    └── BinOp(+)
        ├── Variable(x)
        └── Numero(5)

Gramática del mini-lenguaje:
    programa   -> asignacion*
    asignacion -> ID "=" expresion
    expresion  -> termino (("+" | "-") termino)*
    termino    -> factor  (("*" | "/") factor)*
    factor     -> NUM | ID | "(" expresion ")"
"""

import re

# ============================ NODOS DEL AST ============================

class Nodo:
    """Clase base de todos los nodos."""
    pass


class NodoNumero(Nodo):
    def __init__(self, valor):
        self.valor = valor


class NodoVariable(Nodo):
    def __init__(self, nombre):
        self.nombre = nombre


class NodoBinOp(Nodo):
    def __init__(self, izquierda, operador, derecha):
        self.izquierda = izquierda
        self.operador = operador
        self.derecha = derecha


class NodoAsignacion(Nodo):
    def __init__(self, nombre, valor):
        self.nombre = nombre   # nombre de la variable (str)
        self.valor = valor     # nodo con la expresión


class NodoPrograma(Nodo):
    def __init__(self, sentencias):
        self.sentencias = sentencias


# ============================ LEXER ============================

TOKENS = [
    ("NUM", r"\d+"), ("ID", r"[A-Za-z_]\w*"), ("ASSIGN", r"="),
    ("OP", r"[+\-*/]"), ("LPAREN", r"\("), ("RPAREN", r"\)"),
    ("NEWLINE", r"[\n;,]+"),   # salto de línea, ';' o ',' separan sentencias
    ("SKIP", r"[ \t]+"), ("ERROR", r"."),
]
REGEX = re.compile("|".join(f"(?P<{n}>{p})" for n, p in TOKENS))


def tokenizar(codigo):
    tokens = []
    for m in REGEX.finditer(codigo):
        tipo, valor = m.lastgroup, m.group()
        if tipo == "SKIP":
            continue
        if tipo == "ERROR":
            raise SyntaxError(f"Carácter inesperado '{valor}'")
        tokens.append((tipo, valor))
    tokens.append(("FIN", None))
    return tokens


# ============================ PARSER -> AST ============================

class Parser:
    def __init__(self, codigo):
        self.tokens = tokenizar(codigo)
        self.pos = 0

    def actual(self):
        return self.tokens[self.pos]

    def consumir(self, tipo_esperado):
        tipo, valor = self.actual()
        if tipo != tipo_esperado:
            raise SyntaxError(f"Se esperaba {tipo_esperado}, se encontró '{valor}'")
        self.pos += 1
        return valor

    def programa(self):
        sentencias = []
        while self.actual()[0] != "FIN":
            if self.actual()[0] == "NEWLINE":     # líneas vacías
                self.pos += 1
                continue
            sentencias.append(self.asignacion())
        return NodoPrograma(sentencias)

    def asignacion(self):
        nombre = self.consumir("ID")
        self.consumir("ASSIGN")
        return NodoAsignacion(nombre, self.expresion())

    def expresion(self):
        nodo = self.termino()
        while self.actual()[1] in ("+", "-"):
            op = self.consumir("OP")
            nodo = NodoBinOp(nodo, op, self.termino())   # el árbol crece hacia arriba
        return nodo

    def termino(self):
        nodo = self.factor()
        while self.actual()[1] in ("*", "/"):
            op = self.consumir("OP")
            nodo = NodoBinOp(nodo, op, self.factor())
        return nodo

    def factor(self):
        tipo, valor = self.actual()
        if tipo == "NUM":
            self.pos += 1
            return NodoNumero(int(valor))
        if tipo == "ID":
            self.pos += 1
            return NodoVariable(valor)
        if tipo == "LPAREN":
            self.pos += 1
            nodo = self.expresion()
            self.consumir("RPAREN")
            return nodo
        raise SyntaxError(f"Expresión inválida cerca de '{valor}'")


# ============================ IMPRESIÓN DEL ÁRBOL ============================

def imprimir_ast(nodo, nivel=0):
    """Recorre el AST recursivamente e imprime cada nodo con indentación."""
    sangria = "    " * nivel
    if isinstance(nodo, NodoPrograma):
        print(f"{sangria}Programa")
        for s in nodo.sentencias:
            imprimir_ast(s, nivel + 1)
    elif isinstance(nodo, NodoAsignacion):
        print(f"{sangria}Asignacion: {nodo.nombre}")
        imprimir_ast(nodo.valor, nivel + 1)
    elif isinstance(nodo, NodoBinOp):
        print(f"{sangria}BinOp: {nodo.operador}")
        imprimir_ast(nodo.izquierda, nivel + 1)
        imprimir_ast(nodo.derecha, nivel + 1)
    elif isinstance(nodo, NodoNumero):
        print(f"{sangria}Numero: {nodo.valor}")
    elif isinstance(nodo, NodoVariable):
        print(f"{sangria}Variable: {nodo.nombre}")


# ===================== EXTRA: ejecutar el AST (intérprete) =====================

def evaluar(nodo, memoria):
    if isinstance(nodo, NodoPrograma):
        for s in nodo.sentencias:
            evaluar(s, memoria)
        return memoria
    if isinstance(nodo, NodoAsignacion):
        memoria[nodo.nombre] = evaluar(nodo.valor, memoria)
        return memoria[nodo.nombre]
    if isinstance(nodo, NodoNumero):
        return nodo.valor
    if isinstance(nodo, NodoVariable):
        if nodo.nombre not in memoria:
            raise NameError(f"Variable '{nodo.nombre}' no definida")
        return memoria[nodo.nombre]
    if isinstance(nodo, NodoBinOp):
        a, b = evaluar(nodo.izquierda, memoria), evaluar(nodo.derecha, memoria)
        return {"+": a + b, "-": a - b, "*": a * b, "/": a / b if b else None}[nodo.operador]


if __name__ == "__main__":
    codigo = """
x = 10
y = x + 5
z = (x + y) * 2
"""
    print("Código fuente:", codigo)
    ast = Parser(codigo).programa()
    print("AST generado:")
    imprimir_ast(ast)
    print("\nValores tras ejecutar el AST:", evaluar(ast, {}))

    # Comparación con el módulo ast de Python (inspiración)
    import ast as ast_python
    print("\nAST equivalente según el módulo 'ast' de Python para 'y = x + 5':")
    print(ast_python.dump(ast_python.parse("y = x + 5"), indent=2))
