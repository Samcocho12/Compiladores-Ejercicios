"""
Ejercicio 2 - Parser de descenso recursivo para expresiones aritméticas
Autor: Jorge Mario Prado Medina

Gramática usada (ya SIN recursividad por la izquierda):

    expresion -> termino   (("+" | "-") termino)*
    termino   -> factor    (("*" | "/") factor)*
    factor    -> NUM | "(" expresion ")" | "-" factor

Cada regla de la gramática se convierte en una función. Como "expresion"
llama a "termino" y "termino" llama a "factor", la multiplicación y división
se resuelven ANTES que la suma y la resta: así se respeta la precedencia.

¿Por qué no "expresion -> expresion + termino"? Porque eso es recursividad
por la izquierda: la función expresion() se llamaría a sí misma sin consumir
ningún token y entraría en un bucle infinito. Se reemplaza por un ciclo while.
"""

import re

PATRON = re.compile(r"\s*(?:(\d+\.\d+|\d+)|(.))")


def tokenizar(texto):
    """Lexer mínimo: devuelve lista de (tipo, valor). Tipos: NUM, OP, FIN."""
    tokens = []
    for numero, simbolo in PATRON.findall(texto):
        if numero:
            tokens.append(("NUM", float(numero)))
        elif simbolo.strip():
            tokens.append(("OP", simbolo))
    tokens.append(("FIN", None))  # Marca de fin de entrada
    return tokens


class Parser:
    def __init__(self, texto):
        self.tokens = tokenizar(texto)
        self.pos = 0  # Índice del token actual

    # ---------- utilidades ----------
    def actual(self):
        return self.tokens[self.pos]

    def consumir(self, valor_esperado=None):
        """Avanza al siguiente token, verificando el valor si se indica."""
        tipo, valor = self.actual()
        if valor_esperado is not None and valor != valor_esperado:
            raise SyntaxError(f"Se esperaba '{valor_esperado}', se encontró '{valor}'")
        self.pos += 1
        return valor

    # ---------- reglas de la gramática ----------
    def parsear(self):
        resultado = self.expresion()
        if self.actual()[0] != "FIN":
            raise SyntaxError(f"Token inesperado al final: '{self.actual()[1]}'")
        return resultado

    def expresion(self):
        # expresion -> termino (("+" | "-") termino)*
        valor = self.termino()
        while self.actual()[1] in ("+", "-"):
            op = self.consumir()
            derecho = self.termino()
            valor = valor + derecho if op == "+" else valor - derecho
        return valor

    def termino(self):
        # termino -> factor (("*" | "/") factor)*
        valor = self.factor()
        while self.actual()[1] in ("*", "/"):
            op = self.consumir()
            derecho = self.factor()
            if op == "*":
                valor = valor * derecho
            else:
                if derecho == 0:
                    raise ZeroDivisionError("División entre cero")
                valor = valor / derecho
        return valor

    def factor(self):
        # factor -> NUM | "(" expresion ")" | "-" factor
        tipo, valor = self.actual()
        if tipo == "NUM":
            self.consumir()
            return valor
        if valor == "(":
            self.consumir("(")
            resultado = self.expresion()   # <- aquí está la RECURSIÓN
            self.consumir(")")
            return resultado
        if valor == "-":                   # menos unario: -5, -(2+3)
            self.consumir("-")
            return -self.factor()
        raise SyntaxError(f"Se esperaba un número o '(', se encontró '{valor}'")


def evaluar(texto):
    resultado = Parser(texto).parsear()
    # Mostrar 11 en vez de 11.0 cuando el resultado es entero
    return int(resultado) if resultado == int(resultado) else resultado


if __name__ == "__main__":
    pruebas = [
        "2 + 3 * (4 - 1)",   # 11
        "10 / 2 - 3",        # 2
        "(1 + 2) * (3 + 4)", # 21
        "2 * 3 + 4 * 5",     # 26
        "-(2 + 3) * 2",      # -10
        "7 / 2",             # 3.5
    ]
    for p in pruebas:
        print(f"{p:<22} = {evaluar(p)}")
