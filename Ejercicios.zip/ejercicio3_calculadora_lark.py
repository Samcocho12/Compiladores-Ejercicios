"""
Ejercicio 3 - Calculadora con gramática EBNF y la librería Lark
Autor: Jorge Mario Prado Medina

Instalación:  pip install lark

Lark recibe la gramática escrita en una notación tipo EBNF, genera el parser
automáticamente y produce un árbol. Un "Transformer" recorre ese árbol y
calcula el resultado.

Convenciones de Lark:
  - reglas en minúscula (expr, term, factor)
  - terminales (tokens) en MAYÚSCULA (NUMBER, WS)
  - "?" delante de una regla: si la regla tiene un solo hijo, no crea nodo
    (el árbol queda más limpio)
  - "-> nombre": le pone un alias a esa alternativa para el Transformer
  - | alternativa,  * cero o más,  + uno o más,  ? opcional
"""

from lark import Lark, Transformer

# ------------------------- GRAMÁTICA EBNF -------------------------
GRAMATICA = r"""
    ?start: expr

    ?expr: term
         | expr "+" term     -> suma
         | expr "-" term     -> resta

    ?term: factor
         | term "*" factor   -> mult
         | term "/" factor   -> div

    ?factor: NUMBER          -> numero
           | "-" factor      -> negativo
           | "(" expr ")"

    %import common.NUMBER
    %import common.WS
    %ignore WS
"""
# Nota: aquí SÍ hay recursividad por la izquierda (expr: expr "+" term).
# Lark lo permite porque con parser="lalr" analiza de abajo hacia arriba
# (bottom-up), a diferencia del descenso recursivo del ejercicio 2.


class Calculadora(Transformer):
    """Cada método se llama igual que el alias de la regla en la gramática."""

    def numero(self, hijos):
        return float(hijos[0])

    def suma(self, hijos):
        return hijos[0] + hijos[1]

    def resta(self, hijos):
        return hijos[0] - hijos[1]

    def mult(self, hijos):
        return hijos[0] * hijos[1]

    def div(self, hijos):
        return hijos[0] / hijos[1]

    def negativo(self, hijos):
        return -hijos[0]


# parser="lalr" es rápido; transformer=... evalúa mientras parsea
parser = Lark(GRAMATICA, parser="lalr")
calculadora = Calculadora()


def calcular(texto):
    arbol = parser.parse(texto)
    resultado = calculadora.transform(arbol)
    return int(resultado) if resultado == int(resultado) else resultado


if __name__ == "__main__":
    # Mostramos el árbol que genera Lark para una expresión
    expresion = "2 + 3 * (4 - 1)"
    print("Árbol de Lark para:", expresion)
    print(parser.parse(expresion).pretty())

    pruebas = ["2 + 3 * (4 - 1)", "(5 + 5) * 3", "100 - 4 * 5", "-3 + 10", "9 / 2"]
    for p in pruebas:
        print(f"{p:<18} = {calcular(p)}")
